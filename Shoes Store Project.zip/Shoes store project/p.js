
let total=[];
let totalsum=0;
let product=["Laptop ","phone","bag","pen","eraser","pencil"];
let price=[70000,40000,1000,20,5,10]
let quantity=[10,20,10,10,5,10]
for(let i=0;i<product.length;i++){
  total[i]= price[i]*quantity[i];
}
console.table("product price quantity total");
for(let i=0;i<product.length;i++){
  console.table(product[i]+"\t"+price[i]+"\t"+quantity[i]+"\t"+total[i]);
}
for(let i=0;i<product.length;i++){
  totalsum=totalsum+total[i];
}
console.log("total sum="+totalsum+"\n");

let stock=[100,30,80,60,40,20]
console.table("product\tprice\tquantity stock");
for(let i=0;i<product.length;i++){
  console.table(product[i]+"\t"+price[i]+"\t"+quantity[i]+"\t"+(stock[i]-quantity[i]));
}

  let a=prompt("Enter a product name");
for(let i=0;i<product.length;i++){
  if(product[i]===a){
    console.log("Product found");
       f++;
  }
}
if(f==0){
  console.log("Product not found");
}
  




